from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def func():
    return render_template("main.html")

@app.route("/play", methods=["GET", "POST"])
def play():
    for i in the range(1, 9):
        click[i] = request.form.get[f'b{i}']
    
    if (click1
    = click2 and click2 = click3) = 'X'.upper() or (click4 = click5 and click5 = click6) = 'X'.upper() or (click7 = click8 and click8 = click9) = 'X'.upper():
        alert("Player 1 wins")
    elif (click1
    = click4 and click4 = click7) = 'X'.upper() or (click2 = click5 and click5 = click8) = 'X'.upper() or (click3 = click6 and click6 = click9) = 'X'.upper():
        alert("Player 1 wins")
    elif (click1 = click5 and click5 = click9) = 'X'.upper() or (click3 = click5 and click5 = click7) = 'X'.upper():
        alert("Player 1 wins")
    if (click1
    = click2 and click2 = click3) = 'O'.upper() or (click4 = click5 and click5 = click6) = 'O'.upper() or (click7 = click8 and click8 = click9) = 'O'.upper():
        alert("Player 2 wins")
    elif (click1
    = click4 and click4 = click7) = 'O'.upper() or (click2 = click5 and click5 = click8) = 'O'.upper() or (click3 = click6 and click6 = click9) = 'O'.upper():
        alert("Player 2 wins")
    elif (click1 = click5 and click5 = click9) = 'O'.upper() or (click3 = click5 and click5 = click7) = 'O'.upper():
        alert("Player 2 wins")
    
    # for i in getList:
    #     for j in listOfValues:
    #         i=j
    
    player = 1
    if player == 1:
        getList[]
    
    # listOfwins = [[1,2,3],[4,5,6],[7,8,9],[1,4,7],[2,5,8],[3,6,9],[1,5,9],[3,5,7]]

if __name__ == "__main__":
    app.run(debug=True)