from flask import Flask, render_template, request, redirect

app = Flask(__name__)


@app.route("/")
def play():
    return render_template('index.html')

# def display():
#     disp = """
#        1 | 2 | 3 <br>
#        -----------<br>
#        4 | 5 | 6<br>
#        -----------<br>
#        7 | 8 | 9<br>
#        """
#
#     print(disp)
#     return disp


@app.route('/', methods =['POST'])
def process():
	click = request.form['click']
	return redirect(url_for('index'))




if __name__ == "__main__":
    app.run(debug=True)