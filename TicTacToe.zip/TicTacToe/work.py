#
#
# board = {
#     "1": " ", "2": " ", "3": " ",
#     "4": " ", "5": " ", "6": " ",
#     "7": " ", "8": " ", "9": " "
# }
#
#
# boardX = [list(board.keys())[:3], list(board.keys())[3:6], list(board.keys())[6:9],
#           ['1', '4', '7'], ['2', '5', '8'], ['3', '6', '9'], ['1', '5', '9'], ['3', '5', '7']]
#
# moves = 0
# player = 1
# end_check = 0
# bonny = {'X': "1", 'O': "2"}
#
#
# def check():
#     for element in boardX:
#         if board[element[0]] != " " and board[element[0]] == board[element[1]] and board[element[1]] == board[element[2]]:
#             print(f"Player {bonny[board[element[0]]]} Wins!\n")
#             return True
#
#
# while True:
#     if moves == 9 or end_check == 1:
#         quit()
#
#     while True:
#         if player == 1:
#             p1 = input("Player 1:")
#             if p1.upper() in board and board[p1.upper()] == " ":
#                 board[p1.upper()] = 'X'
#                 player = 2
#                 moves += 1
#                 end_check = check()
#                 break
#             else:
#                 print("!!! Invalid Input !!!")
#         else:
#             if player == 2:
#                 p2 = input("Player 2:")
#                 if p2.upper() in board and board[p2.upper()] == " ":
#                     board[p2.upper()] = 'O'
#                     player = 1
#                     moves += 1
#                     end_check = check()
#                     break
#                 else:
#                     print("!!! Invalid Input !!!")
#
#         if end_check:
#             break
