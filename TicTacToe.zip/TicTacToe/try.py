from flask import Flask, request, redirect, url_for, render_template
import random

app = Flask(__name__)

# options = ["O", "X"]


# @app.route("/", methods=["GET", "POST"])
# def trying():
#     return render_template("try.html")


# if __name__ == "__main__":
#     app.run(debug=True)
  
# board = {
#     "1": " ", "2": " ", "3": " ",
#     "4": " ", "5": " ", "6": " ",
#     "7": " ", "8": " ", "9": " "
# }

# boardX = [list(board.keys())[:3], list(board.keys())[3:6], list(board.keys())[6:9],
#           ['1', '4', '7'], ['2', '5', '8'], ['3', '6', '9'], ['1', '5', '9'], ['3', '5', '7']]

# moves = 0
# player = 1
# end_check = 0
# bonny = {'X': "1", 'O': "2"}


# def click():
#     for element in boardX:
#         if board[element[0]] != " " and board[element[0]] == board[element[1]] and board[element[1]] == board[element[2]]:
#             return f"Player {bonny[board[element[0]]]} Wins!\n"
          
          
# while True:
#     if moves == 9 or end_check == 1:
#         quit()

#     while True:
#         clickme = request.form['clickme']
#         if player == 1:
#             # p1 = input("Player 1:")
#             if clickme in board and board[clickme] == " ":
#                 board[clickme] = 'X'
#                 player = 2
#                 moves += 1
#                 end_check = click()
#                 break
#             else:
#                 print("!!! Invalid Input !!!")
#         else:
#             if player == 2:
#                 # p2 = input("Player 2:")
#                 if clickme in board and board[clickme] == " ":
#                     board[clickme] = 'O'
#                     player = 1
#                     moves += 1
#                     end_check = click()
#                     break
#                 else:
#                     print("!!! Invalid Input !!!")

#         if end_check:
#             break
    
    
        


@app.route('/, methods =['GET', 'POST'])
def click():
	click = request.form['click']
	return render_template("try.html")

# def submit(): 
	

