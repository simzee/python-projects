from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def play():
    return render_template('string')


@app.route("/")
def display():
    disp = """
    1 | 2 | 3 <br>
    -----------<br>
    4 | 5 | 6<br>
    -----------<br>
    7 | 8 | 9<br>
    """

    print(disp)
    return disp


board = {
    "1": " ", "2": " ", "3": " ",
    "4": " ", "5": " ", "6": " ",
    "7": " ", "8": " ", "9": " "
}


boardX = [list(board.keys())[:3], list(board.keys())[3:6], list(board.keys())[6:9],
          ['1', '4', '7'], ['2', '5', '8'], ['3', '6', '9'], ['1', '5', '9'], ['3', '5', '7']]

moves = 0
player = 1
end_check = 0
bonny = {'X': "1", 'O': "2"}


def check():
    for element in boardX:
        if board[element[0]] != " " and board[element[0]] == board[element[1]] and board[element[1]] == board[element[2]]:
            return f"Player {bonny[board[element[0]]]} Wins!\n"


    string = """
    <!doctype html>
    <html lang="en">
      <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">

        <title>Tic Tac Toe</title>
      </head>
      <body>
        <table class="table">
      <tbody>"""

    for i in range(3):
        string += '<tr class="col-sm">'
        for j in range(3):
            string += f'<td class="col-sm"> <button type="button" class="btn btn-warning">{board[str(3*i+(j+1))]}</button></td>'
        string += '</tr>'

    string += """</tbody>

    </table>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
      </body>
    </html>
    """


while True:
    if moves == 9 or end_check == 1:
        quit()

    while True:
        if player == 1:
            p1 = input("Player 1:")
            if p1.upper() in board and board[p1.upper()] == " ":
                board[p1.upper()] = 'X'
                player = 2
                moves += 1
                end_check = check()
                break
            else:
                print("!!! Invalid Input !!!")
        else:
            if player == 2:
                p2 = input("Player 2:")
                if p2.upper() in board and board[p2.upper()] == " ":
                    board[p2.upper()] = 'O'
                    player = 1
                    moves += 1
                    end_check = check()
                    break
                else:
                    print("!!! Invalid Input !!!")

        if end_check:
            break

app.run(debug=True)